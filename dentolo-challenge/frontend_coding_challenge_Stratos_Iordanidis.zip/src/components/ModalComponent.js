import React, { Component } from 'react'

import '../css/ModalComponent.scss'

class ModalComponent extends Component {

  closeModal = () => {
    this.props.closeModal()
  }

  render() {
    const { name, email } = this.props

    return (
      <div className="ModalComponent">
        <div className="modal-bg" onClick={() => this.closeModal()} />

        <div className="modal-content">
          <h2>Name is:</h2>
          <h1>{name}</h1>

          <h2>Email is:</h2>
          <h1>{email}</h1>

          <button onClick={() => this.closeModal()} >Close Modal</button>
        </div>
      </div>
    )
  }
}

export default ModalComponent