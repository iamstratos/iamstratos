import React, { Component } from 'react'
import PropTypes from 'prop-types'

import '../css/FormComponent.scss'

class FormComponent extends Component {
  state = {
    name: '',
    email: ''
  }

  handleChange = (e) => {
    this.setState({
      [e.target.name]: e.target.value
    })
  }

  handleSubmit = (e) => {
    e.preventDefault()
    const { name, email } = this.state

    if (name && email) {
      this.props.openModal(name, email)
    }
  }

  render() {
    const { name, email } = this.state

    return (
      <form className="FormComponent" onSubmit={(e) => this.handleSubmit(e)}>
        <label htmlFor="#name">Name:</label>
        <input
          id="name" type="text" name="name"
          required placeholder="Type your name"
          onChange={(e) => this.handleChange(e)}
        />

        <label htmlFor="#email">Email:</label>
        <input
          id="email" type="email" name="email"
          required placeholder="Type your email"
          onChange={(e) => this.handleChange(e)}
        />

        <button type="submit" disabled={ !name || !email } >CONFIRM</button>
      </form>
    )
  }
}

FormComponent.propTypes = {
  name: PropTypes.string,
  email: PropTypes.string
}

FormComponent.defaultProps = {
  name: '',
  email: ''
}

export default FormComponent