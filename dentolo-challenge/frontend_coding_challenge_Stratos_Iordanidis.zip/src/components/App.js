import React, { Component } from 'react'
import PropTypes from 'prop-types'

import BoxComponent from './BoxComponent'

import '../css/styles.scss'
import FormComponent from './FormComponent';
import ModalComponent from './ModalComponent';

class App extends Component {
  state = {
    modalOpen: false,
    modalCount: 0,
    name: '',
    email: ''
  }

  openModal = (name, email) => {
    this.setState({
      name,
      email,
      modalOpen: true
    })
  }

  closeModal = () => {
    this.setState({
      modalOpen: false,
      modalCount: this.state.modalCount + 1
    })
  }

  render() {
    const { modalOpen, modalCount, name, email } = this.state

    return (
      <React.Fragment>
        <BoxComponent modalCount={modalCount} />
        <FormComponent openModal={this.openModal}/>
        {
          modalOpen
          &&
          <ModalComponent name={name} email={email} closeModal={this.closeModal}/>
        }
      </React.Fragment>
    )
  }
}

App.propTypes = {
  modalOpen: PropTypes.bool,
  modalCount: PropTypes.number,
  name: PropTypes.string,
  email: PropTypes.string
}

App.defaultProps = {
  modalOpen: false,
  modalCount: 0,
  name: '',
  email: ''
}

export default App