import React from 'react'

import '../css/BoxComponent.scss'

const BoxComponent = ({ modalCount }) => {
    return (
        <div className="BoxComponent">
            <h2>React Component</h2>
            <p className="modal-open-count">
                Modal Open Count:
                <strong> {modalCount}</strong>
            </p>
        </div>
    )
}

export default BoxComponent