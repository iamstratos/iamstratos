# Coding Challenge for Frontend(HTML/CSS, React.js)

## Environment
- node v8.5.0
- yarn
- react v16.2.0
- webpack


## Preparation

```
$ yarn
```

## Run app

```
$ npm run dev
```

You can then see the initial view on `localhost:8080`

---

Please implement it like the above animation with React.js (see animated gif in public directory). It does not need to be exactly the same from the design point of view.

**Requirements**
1. Prepare two forms for the name and email.
2. Once the "Confirm" button is clicked, show the values in the modal.
3. Make it possible to count how many times the modal was opened.
4. Create the view, so it is responsive for mobile devices.
*) Please design it without using a CSS framework such as bootstrap. You can add JS libraries if you want to.
